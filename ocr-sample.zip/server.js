import express from 'express';
import path from 'path'
import multer from 'multer';
// import { PDFDocument } from 'pdf-lib';
import PdfParse from 'pdf-parse';
import Jimp from 'jimp';
import jsQR from 'jsqr';
import fs from 'fs'
// import jsQR from 'jsqr';
// import sharp from 'sharp';
// import { createCanvas } from 'canvas';
// import { getDocument } from 'pdfjs-dist/build/pdf.min.mjs';

// const __dirname = import.meta.dirname;
const app = express();


const upload = multer({storage: multer.memoryStorage()})
// Function to extract images from PDF and look for QR code
const extractQRCodeFromPDF = async (pdfBuffer) => {
    // const dataBuffer = fs.readFileSync(pdfFilePath);
    const pdfBufferr = fs.readFileSync('./public/assets/file-samples/QRCodeFieldExamples.pdf');
  const data = await PdfParse(pdfBufferr);

  for (const image of data.images) {
    const imageData = await Jimp.read(Buffer.from(image.data, 'base64'));
    const code = jsQR(imageData.bitmap.data, imageData.bitmap.width, imageData.bitmap.height);

    if (code) {
      const pdfPage = data.Pages[image.pageIndex]; // Assuming pdf-parse provides page info
      // Translate image coordinates to PDF page coordinates
      // ...
      return {
        page: image.pageIndex + 1,
        x: code.location.topLeftCorner.x,
        y: code.location.topLeftCorner.y,
        width: code.location.bottomRightCorner.x - code.location.topLeftCorner.x,
        height: code.location.bottomRightCorner.y - code.location.topLeftCorner.y,
      };
    }
  }

  return null; // No QR code found
    // try {
    //     // Load the image with Jimp
    //     const image = await Jimp.read('./public/assets/file-samples/qr-sample.PNG');

    //     // Get the image data
    //     const imageData = {
    //         data: new Uint8ClampedArray(image.bitmap.data),
    //         width: image.bitmap.width,
    //         height: image.bitmap.height,
    //     };

    //     // Use jsQR to decode the QR code
    //     const decodedQR = jsQR(imageData.data, imageData.width, imageData.height);

    //     if (!decodedQR) {
    //         throw new Error('QR code not found in the image.');
    //     }

    //     return decodedQR.data;
    // } catch (error) {
    //     console.error('Error decoding QR code:', error);
    // }

    // const pdfDoc = await PDFDocument.load(pdfBuffer);
    // const pages = pdfDoc.getPages();
    // let text = '';

    // for (const page of pages) {
    //     text += await page.getTextContent().then(content => content.items.map(item => item.str).join(' '));
    // }

    // return text;
};

// Route to handle PDF upload and QR code extraction
app.post('/upload-pdf', upload.single('file'), async (req, res) => {
    try {
        const qrCodeContent = await extractQRCodeFromPDF(req.file.buffer);

        if (qrCodeContent) {
            res.send(`QR Code Content: ${qrCodeContent}`);
        } else {
            res.send('No QR code found in the PDF.');
        }
    } catch (error) {
        res.status(500).send(`Error processing PDF: ${error.message}`);
    }
});
app.use(express.urlencoded({extended: true}))
app.use(express.static('public'))
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


const PORT = process.env.port || 3000

app.listen(PORT, () => {
    console.log(`Server Started and Running on PORT ${PORT}`)
})

